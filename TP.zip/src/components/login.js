import React, { useState } from 'react';
import './login.css'; // Import the CSS file
import {Card} from "react-bootstrap";
import quote from "../images/appl.jpeg"
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Cookies from 'js-cookie';


const LoginPage = ({ onLoginSuccess }) => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    Cookies.set('userId', userId);
    
    let postdata = {
      "customer_email": userId,
      "password": password
    }

    try {
      const response = await axios.post("https://vt1byeh9we.execute-api.us-east-1.amazonaws.com/login/login", postdata);
      
      console.log(response);
  
      if (response.data.body === "Login successful!") {
        onLoginSuccess();
        alert(response.data.body);
        navigate("/dashboard");
      } else {
        alert("Please try again.");
        console.log(response.data.body);
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert("An error occurred during login. Please try again.");
    }
    
  };


  return (
    <Card className='cardStyle' style={{ width: '18rem' }}>
    <Card.Body>
    <Card.Title>Welcome, Esteemed Restaurant Owner!</Card.Title>
      <form onSubmit={handleLoginSubmit}>
            <label style={{color:"#f2a183", fontWeight: 'bold'}}htmlFor="userId">User ID:</label>
            <input
              type="text"
              id="userId"
              autoComplete="off"
              onChange={(e) => setUserId(e.target.value)}
              value={userId}
              required
            />
            <label style={{color:"#f2a183", fontWeight: 'bold'}} htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              onChange={(e) => setPassword(e.target.value)}
              value={password}
              required
            />
            <button style= {{backgroundColor: "#C08261"}}type="submit">Sign In</button>
            <br/>
            <a href="/register" style={{ display: 'block', margin: 'auto', textAlign: 'center' }}>
  Not Registered?
</a>
          </form>
    </Card.Body>
  </Card>
  );
};

export default LoginPage;
