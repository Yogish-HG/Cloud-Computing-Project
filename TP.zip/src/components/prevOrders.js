import React, { useEffect, useState } from 'react';
import { Navbar, Container, Nav, Card, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Dashboard.css';
import axios from 'axios';
import groc from '../images/card.jpg';
import bg from '../images/background.jpg';
import Cookies from 'js-cookie';

export default function Prevord() {
    const [ordersPrev, setItems] = useState([]);
    const [userId, setUserId] = useState('');

    useEffect(() => {
    const userIdFromCookies = Cookies.get('userId');
    
    // Log the userId obtained from Cookies
    console.log(userIdFromCookies);

    // Set the userId in the component state
    setUserId(userIdFromCookies);
        setUserId(Cookies.get('userId'));
        let payload = {
            "email": userIdFromCookies
        };
        console.log(payload);

        axios.post("https://vt1byeh9we.execute-api.us-east-1.amazonaws.com/prev/prevOrder", payload)
            .then((resp) => {
                setItems(resp.data.body[0].orders);
                console.log(resp);
            })
            .catch((error) => {
                console.error("Error in async operation:", error);
            });

    }, []);

    return (
        <div>
            {ordersPrev && ordersPrev.length > 0 ? (
                ordersPrev.map((order, index) => (
                    <div key={index}>
                        {order.map((item, itemIndex) => (
                            <div key={itemIndex}>
                                {item['total amount'] ? (
                                    <p>Total Amount: {item['total amount']}</p>
                                ) : (
                                    item['name'] && item['quantity'] && (
                                        <p>
                                            Name: {item['name']}, Quantity: {item['quantity']}
                                        </p>
                                    )
                                )}
                            </div>
                        ))}
                    </div>
                ))
            ) : (
                <p>No orders available.</p>
            )}
        </div>
    );
    
}
