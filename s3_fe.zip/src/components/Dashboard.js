import React, { useEffect, useState } from 'react'
import{Navbar, Container, Nav, Card, Button} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';
import './Dashboard.css';
import axios from'axios';
import groc from '../images/card.jpg'
import bg from '../images/background.jpg'
import Cookies from 'js-cookie';
export default function Dashboard() {
    const [items,setItems]=useState([]);
    const [userId, setUserId] = useState('');
    const handleItems=(async()=>{
      
        let ord=[];
        let amount=0;
        items.map((item)=>{
          ord.push({
            "name":item.name,
            "quantity":String(parseInt(document.getElementById(item.name).value)),
            "metric": item.metric
          })
          amount=amount+parseInt(document.getElementById(item.name).value*item.price)
        })
        ord.push({"total amount": String(amount)})
        console.log(ord)
        let payload={
          "email": userId,
          "orders":ord
        }
        // let resp = await axios.post("https://vt1byeh9we.execute-api.us-east-1.amazonaws.com/order/addOrder", payload)
        let resp = await axios.post("https://bqsyk1r8gk.execute-api.us-east-1.amazonaws.com/dev/order", payload)
        console.log(resp)
        // send post request to lambda which sends mail here
        if(resp.data === 'Orders added successfully'){
          // let resp2 = await axios.post("https://vt1byeh9we.execute-api.us-east-1.amazonaws.com/mail/send", payload)
          let resp2 = await axios.post("https://bqsyk1r8gk.execute-api.us-east-1.amazonaws.com/dev/mail", payload)
          console.log("resp frm mail");
          console.log(resp2);
        }
        
    }
    )

    useEffect(() => {
      setUserId(Cookies.get('userId'));
      let pl = {
        "email": "constant"
      }
      // axios.get("https://vt1byeh9we.execute-api.us-east-1.amazonaws.com/getItems/getall")
      axios.post("https://bqsyk1r8gk.execute-api.us-east-1.amazonaws.com/dev/getAllItems", pl)
        .then((resp) => {
          console.log(resp)
          setItems(resp.data);
        })
        .catch((error) => {
            console.error("Error in async operation:", error);
          })
      
    }, []);
    
    return (
      <div style={{ backgroundImage: `url(${bg})`, backgroundSize: 'cover', minHeight: '100vh' }}>
      <br/>
      <br />
      <div style={{justifyContent:"center",display:"flex"}}>
      <h3 style={{color:"white"}}>List of Items</h3>
      </div>
      <br />
      <br />
      <div>
      {items && items.map((item)=>
             <Card style={{ width: '18rem', float: 'left', margin: '5px' }}>
             {/* <Card.Img variant="top" src={food}/> */}
             <Card.Body>
             <Card.Img variant="top" src={groc}/>
               <Card.Title>{item.type} : {item.name}</Card.Title>
               <Card.Text>
               Price: {item.price} CAD/{item.metric}<br />
                Quantity : <input type="text" className="input-box" id={item.name}placeholder="Enter quantity..." />
               </Card.Text>
             </Card.Body>
           </Card>
      )}
      </div>
      <div style={{ clear: 'both' }}></div>
      <div style={{marginTop:'4rem', marginLeft:'46rem'}}>
      <Button variant="primary" onClick={handleItems}>Order</Button>
     </div>
      </div>
    )
}
